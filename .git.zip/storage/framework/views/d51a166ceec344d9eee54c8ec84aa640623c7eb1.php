<!DOCTYPE html>
<html lang="en" class="light">
    <!-- BEGIN: Head -->
    <head>
        <meta charset="utf-8">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
        <link href="<?php echo e(asset('mone/images/logo.svg')); ?>" rel="shortcut icon">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Pembelajaran dan pelatihan gratis">
        <meta name="keywords" content="LPKN - Referal registration Pembelajaran dan pelatihan gratis">
        <meta name="author" content="erikwii, z02">
        <title>Referral Registration</title>

        <!-- BEGIN: CSS Assets-->
        <link rel="stylesheet" href="<?php echo e(asset('mone/css/app.css')); ?>" />
        <!-- END: CSS Assets-->

        <!-- BEGIN: JS Assets-->
        <script src="<?php echo e(asset('jquery/jquery.min.js')); ?>"></script>
        <!-- END: JS Assets-->
    </head>
    <!-- END: Head -->
    <body class="login">
        
        <?php echo $__env->yieldContent('content'); ?>

        <script src="<?php echo e(asset('mone/js/app.js')); ?>"></script>
    </body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/referral/resources/views/layouts/registration.blade.php ENDPATH**/ ?>